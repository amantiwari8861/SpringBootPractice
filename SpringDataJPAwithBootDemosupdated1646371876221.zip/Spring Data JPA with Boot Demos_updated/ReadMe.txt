1. Please check and update the database name according to  your local DB.

2. Read the comments given in course demos for proper understanding.
